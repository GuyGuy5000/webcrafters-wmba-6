﻿//Code By= Farooq Jidelola
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using OfficeOpenXml.Style;
using OfficeOpenXml;
using wmbaApp.CustomControllers;
using wmbaApp.Data;
using wmbaApp.Models;
using Microsoft.CodeAnalysis.Elfie.Diagnostics;
using wmbaApp.Utilities;

namespace wmbaApp.Controllers
{
    public class InActivePlayersController : ElephantController
    {
        private readonly WmbaContext _context;

        public InActivePlayersController(WmbaContext context)
        {
            _context = context;
        }

        public async Task<IActionResult> Index(int? page, int? pageSizeID)
        {
            var inactivePlayers = _context.InActivePlayers
                .Include(ip => ip.Teams).ThenInclude(p => p.Division)
                .Include(ip => ip.Statistics)
                .AsNoTracking();

            int pageSize = PageSizeHelper.SetPageSize(HttpContext, pageSizeID, ControllerName());
            ViewData["pageSizeID"] = PageSizeHelper.PageSizeList(pageSize);

            var pagedData = await PaginatedList<InActivePlayer>.CreateAsync(inactivePlayers.AsNoTracking(), page ?? 1, pageSize);

            // Change the return statement to use the pagedData
            return View(pagedData);
        }

        public IActionResult MakeActive(int id)
        {
            var inactivePlayer = _context.InActivePlayers
                .Include(ip => ip.Teams).ThenInclude(p => p.Division)
                .Include(ip => ip.Statistics)
                .OrderBy(p => p.FirstName)
                .FirstOrDefault(m => m.Id == id);

            if (inactivePlayer == null)
            {
                return NotFound();
            }

            if (inactivePlayer.Teams != null && inactivePlayer.Statistics != null)
            {

                var player = new Player
                {
                    ID = inactivePlayer.Id,
                    PlyrFirstName = inactivePlayer.FirstName,
                    PlyrLastName = inactivePlayer.LastName,
                    PlyrJerseyNumber = inactivePlayer.JerseyNumber,
                    PlyrMemberID = inactivePlayer.MemberID,
                    TeamID = inactivePlayer.TeamID,
                    StatisticID = inactivePlayer.StatisticID
                };

                _context.Players.Add(player);
                _context.InActivePlayers.Remove(inactivePlayer);
                _context.SaveChanges();

                return RedirectToAction("Index", "InActivePlayers");
            }
            else
            {
                return BadRequest("Invalid Team or Statistics information for inactive player");
            }
        }


        public IActionResult DownloadInactivePlayersReport()
        {
            // Get the data from the database
            var inactivePlayersData = _context.InActivePlayers

                .OrderBy(ip => ip.FirstName) // Change to the actual property for sorting
                .Select(ip => new
                {
                    Member_ID = ip.MemberID,
                    First_Name = ip.FirstName,
                    Last_Name = ip.LastName,
                    Team = ip.Teams.TmName,
                    Division = ip.Teams.Division.DivName,
                })
                .AsNoTracking();

            // How many rows?
            int numRows = inactivePlayersData.Count();

            if (numRows > 0)
            {
                // Create a new spreadsheet from scratch.
                using (ExcelPackage excel = new ExcelPackage())
                {
                    var workSheet = excel.Workbook.Worksheets.Add("Inactive Players Report");

                    // Note: Cells[row, column]
                    workSheet.Cells[3, 1].LoadFromCollection(inactivePlayersData, true);

                    // Set column styles if needed

                    // Make certain cells bold
                    workSheet.Cells[4, 1, numRows + 3, 1].Style.Font.Bold = true;

                    // Autofit columns
                    workSheet.Cells.AutoFitColumns();

                    // Add a title and timestamp at the top of the report
                    workSheet.Cells[1, 1].Value = "Inactive Players Report";
                    using (ExcelRange Rng = workSheet.Cells[1, 1, 1, 3]) // Adjust the column count accordingly
                    {
                        Rng.Merge = true;
                        Rng.Style.Font.Bold = true;
                        Rng.Style.Font.Size = 18;
                        Rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Center;
                    }

                    DateTime utcDate = DateTime.UtcNow;
                    TimeZoneInfo esTimeZone = TimeZoneInfo.FindSystemTimeZoneById("Eastern Standard Time");
                    DateTime localDate = TimeZoneInfo.ConvertTimeFromUtc(utcDate, esTimeZone);
                    using (ExcelRange Rng = workSheet.Cells[2, 6]) // Adjust the column accordingly
                    {
                        Rng.Value = "Created: " + localDate.ToShortTimeString() + " on " +
                            localDate.ToShortDateString();
                        Rng.Style.Font.Bold = true;
                        Rng.Style.Font.Size = 12;
                        Rng.Style.HorizontalAlignment = ExcelHorizontalAlignment.Right;
                    }

                    // Ok, time to download the Excel
                    try
                    {
                        Byte[] theData = excel.GetAsByteArray();
                        string filename = "InActive Players Report.xlsx";
                        string mimeType = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet";
                        return File(theData, mimeType, filename);
                    }
                    catch (Exception)
                    {
                        return BadRequest("Could not build and download the file.");
                    }
                }
            }
            return NotFound("No data.");
        }

    }
}
