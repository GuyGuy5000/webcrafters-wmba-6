using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace wmbaApp.Views.Shared
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
