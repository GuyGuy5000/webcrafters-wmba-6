﻿namespace wmbaApp.ViewModels
{
    public class GameIndexVM
    {
        public string FullVersus { get; set; }
        public string StartTimeSummary { get; set; }

    }
}
