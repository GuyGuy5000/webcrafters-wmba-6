﻿/// <summary>
/// Game
/// Farooq Jidelola
/// Leon Kamdem
/// </summary>
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using wmbaApp.CustomControllers;
using wmbaApp.Data;
using wmbaApp.Models;
using wmbaApp.Utilities;

namespace wmbaApp.Controllers
{
    public class GamesController : ElephantController
    {
        private readonly WmbaContext _context;

        public GamesController(WmbaContext context)
        {
            _context = context;
        }

        // GET: Games
        //public async Task<IActionResult> Index()
        //{
        //    var wmbaContext = _context.Games
        //        .Include(g => g.AwayTeam)
        //        .Include(g => g.HomeTeam);
        //    return View(await wmbaContext.ToListAsync());
        //}
        public async Task<IActionResult> Index(string SearchString, int? TeamID,
                    int? page, int? pageSizeID, string actionButton, string sortDirection = "asc", string sortField = "")
        {
            // Count the number of filters applied - start by assuming no filters
            ViewData["Filtering"] = "btn-outline-secondary";
            int numberFilters = 0;
            // Then in each "test" for filtering, add to the count of Filters applied

            // List of sort options.
            // NOTE: make sure this array has matching values to the column headings
            string[] sortOptions = new[] { "Game Start", "Game End", "Location" };



            var games = _context.Games
                .Include(g => g.AwayTeam).ThenInclude(p => p.Division)
                .Include(g => g.HomeTeam).ThenInclude(p => p.Division)
                
                .AsNoTracking();

            
            if (!System.String.IsNullOrEmpty(SearchString))
            {
                games = games.Where(g => g.GameLocation.ToUpper().Contains(SearchString.ToUpper())
                || g.HomeTeam.TmName.ToUpper().Contains(SearchString.ToUpper())
                || g.AwayTeam.TmName.ToUpper().Contains(SearchString.ToUpper())
                || g.Division.DivName.ToUpper().Contains(SearchString.ToUpper()));
                
                numberFilters++;
            }



            // Give feedback about the state of the filters
            if (numberFilters != 0)
            {
                // Toggle the Open/Closed state of the collapse depending on if we are filtering
                ViewData["Filtering"] = " btn-danger";
                // Show how many filters have been applied
                ViewData["numberFilters"] = "(" + numberFilters.ToString()
                    + " Filter" + (numberFilters > 1 ? "s" : "") + " Applied)";
            }

            if (!System.String.IsNullOrEmpty(actionButton)) // Form submitted!
            {
                page = 1; // Reset page to start

                if (sortOptions.Contains(actionButton)) // Change of sort is requested
                {
                    if (actionButton == sortField) // Reverse order on same field
                    {
                        sortDirection = sortDirection == "asc" ? "desc" : "asc";
                    }
                    sortField = actionButton; // Sort by the button clicked
                }
            }

            // Sort data based on the selected field and direction
            if (sortField == "Upcoming Games")
            {
                games = sortDirection == "asc" ? games.OrderBy(g => g.FullVersus) : games.OrderByDescending(g => g.FullVersus);
            }
            else if (sortField == "Location")
            {
                games = sortDirection == "asc" ? games.OrderBy(g => g.GameLocation) : games.OrderByDescending(g => g.GameLocation);
            }
    
            // Store sort field and direction in ViewData
            ViewData["sortField"] = sortField;
            ViewData["sortDirection"] = sortDirection;

            // Set page size
            int pageSize = PageSizeHelper.SetPageSize(HttpContext, pageSizeID, ControllerName());
            ViewData["pageSizeID"] = PageSizeHelper.PageSizeList(pageSize);

            // Paginate the data
            var pagedData = await PaginatedList<Game>.CreateAsync(games, page ?? 1, pageSize);

            return View(pagedData);
        }

        // GET: Games/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Games == null)
            {
                return NotFound();
            }

            var game = await _context.Games
                .Include(g => g.AwayTeam)
                .Include(g => g.HomeTeam)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (game == null)
            {
                return NotFound();
            }
            

            return View(game);
        }

        // GET: Games/Create
        public IActionResult Create()
        {
            ViewData["AwayTeamID"] = new SelectList(_context.Teams, "ID", "TmName");
            ViewData["HomeTeamID"] = new SelectList(_context.Teams, "ID", "TmName");
            ViewData["DivisionID"] = new SelectList(_context.Divisions, "ID", "DivName");
            ViewData["GameLocations"] = new SelectList(_context.Games.Select(p => p.GameLocation).Distinct().ToList());
            return View();
        }

        // POST: Games/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,GameStartTime,GameEndTime,IsActive,GameLocation,HomeTeamID,AwayTeamID,DivisionID")] Game game,
            string newGameLocation, int? selectedDivision)
        {
            if (selectedDivision.HasValue)
            {
                ViewData["HomeTeamID"] = new SelectList(_context.Teams.Where(t => t.DivisionID == selectedDivision), "ID", "TmName");
                ViewData["AwayTeamID"] = new SelectList(_context.Teams.Where(t => t.DivisionID == selectedDivision), "ID", "TmName");
            }

            //i'm trying to avoid usingw same Gamelocation be used twice for different games same day.
            if (game.GameStartTime.HasValue && IsGameLocationUsedOnceADay(game.GameStartTime.Value.Date, game.GameLocation))
            {
                ModelState.AddModelError("GameLocation", "Game location can only be used once a day.");
            }


            if (ModelState.IsValid)
            {
                if (game.GameLocation == "Add New" && !string.IsNullOrWhiteSpace(newGameLocation))
                {
                    game.GameLocation = newGameLocation;
                }

                _context.Add(game);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }
            //ViewData["AwayTeamID"] = new SelectList(_context.Teams, "ID", "TmName", game.AwayTeamID);
            //ViewData["HomeTeamID"] = new SelectList(_context.Teams, "ID", "TmName", game.HomeTeamID);
            ViewData["DivisionID"] = new SelectList(_context.Divisions, "ID", "DivName");
            ViewData["GameLocations"] = new SelectList(_context.Games.Select(p => p.GameLocation).Distinct().ToList());
            return View(game);
        }

        // GET: Games/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Games == null)
            {
                return NotFound();
            }

            var game = await _context.Games.FindAsync(id);


            if (game == null)
            {
                return NotFound();
            }
            ViewData["AwayTeamID"] = new SelectList(_context.Teams, "ID", "TmName", game.AwayTeamID);
            ViewData["HomeTeamID"] = new SelectList(_context.Teams, "ID", "TmName", game.HomeTeamID);
            ViewData["DivisionID"] = new SelectList(_context.Divisions, "ID", "DivName");
            ViewData["GameLocations"] = new SelectList(_context.Games.Select(p => p.GameLocation).Distinct().ToList());
            return View(game);
        }

        // POST: Games/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,GameStartTime,GameEndTime,IsActive,GameLocation,HomeTeamID,AwayTeamID,DivisionID")] Game game,
            string newGameLocation, int? selectedDivision)
        {
            if (id != game.ID)
            {
                return NotFound();
            }

            if (selectedDivision.HasValue)
            {
                ViewData["HomeTeamID"] = new SelectList(_context.Teams.Where(t => t.DivisionID == selectedDivision), "ID", "TmName", game.HomeTeamID);
                ViewData["AwayTeamID"] = new SelectList(_context.Teams.Where(t => t.DivisionID == selectedDivision), "ID", "TmName", game.AwayTeamID);
            }

            if (ModelState.IsValid)
            {
                try
                {
                    if (game.GameLocation == "Add New" && !string.IsNullOrWhiteSpace(newGameLocation))
                    {
                        game.GameLocation = newGameLocation;
                    }
                    _context.Update(game);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!GameExists(game.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }
            //ViewData["AwayTeamID"] = new SelectList(_context.Teams, "ID", "TmName", game.AwayTeamID);
            //ViewData["HomeTeamID"] = new SelectList(_context.Teams, "ID", "TmName", game.HomeTeamID);
            ViewData["DivisionID"] = new SelectList(_context.Divisions, "ID", "DivName");
            ViewData["GameLocations"] = new SelectList(_context.Games.Select(p => p.GameLocation).Distinct().ToList());
            return View(game);
        }

        // GET: Games/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Games == null)
            {
                return NotFound();
            }

            var game = await _context.Games
                .Include(g => g.AwayTeam)
                .Include(g => g.HomeTeam)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (game == null)
            {
                return NotFound();
            }

            return View(game);
        }

        // POST: Games/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Games == null)
            {
                return Problem("Entity set 'WmbaContext.Games'  is null.");
            }
            var game = await _context.Games.FindAsync(id);
            if (game != null)
            {
                _context.Games.Remove(game);
            }
            
            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        public IActionResult SelectLineup(int gameId)
        {
            return RedirectToAction("Create", "Lineups", new { gameId });
        }

        private bool IsGameLocationUsedOnceADay(DateTime gameDate, string gameLocation)
        {
            return _context.Games.Any(g => g.GameStartTime == gameDate && g.GameLocation == gameLocation);
        }

        [HttpGet]
        public JsonResult GetTeamsByDivision(int divisionId)
        {
            var teams = _context.Teams
                .Where(t => t.DivisionID == divisionId)
                .Select(t => new { id = t.ID, name = t.TmName })
                .ToList();

            return Json(new { teams });
        }


        private bool GameExists(int id)
        {
          return _context.Games.Any(e => e.ID == id);
        }
    }
}
