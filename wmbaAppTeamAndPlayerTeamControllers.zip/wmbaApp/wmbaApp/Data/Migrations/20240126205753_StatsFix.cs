﻿using System;
using Microsoft.EntityFrameworkCore.Migrations;

#nullable disable

namespace wmbaApp.Data.Migrations
{
    /// <inheritdoc />
    public partial class StatsFix : Migration
    {
        /// <inheritdoc />
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Players_Statistics_StatisticsID",
                table: "Players");

            migrationBuilder.DropForeignKey(
                name: "FK_Players_Teams_TeamID",
                table: "Players");

            migrationBuilder.DropColumn(
                name: "StatsID",
                table: "Players");

            migrationBuilder.RenameColumn(
                name: "StatisticsID",
                table: "Players",
                newName: "StatisticID");

            migrationBuilder.RenameIndex(
                name: "IX_Players_StatisticsID",
                table: "Players",
                newName: "IX_Players_StatisticID");

            migrationBuilder.AddColumn<DateTime>(
                name: "PlyrDOB",
                table: "Players",
                type: "TEXT",
                nullable: true);

            migrationBuilder.AlterColumn<DateTime>(
                name: "GameStartTime",
                table: "Games",
                type: "TEXT",
                nullable: true,
                oldClrType: typeof(DateTime),
                oldType: "TEXT");

            migrationBuilder.AddForeignKey(
                name: "FK_Players_Statistics_StatisticID",
                table: "Players",
                column: "StatisticID",
                principalTable: "Statistics",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Players_Teams_TeamID",
                table: "Players",
                column: "TeamID",
                principalTable: "Teams",
                principalColumn: "ID",
                onDelete: ReferentialAction.Restrict);
        }

        /// <inheritdoc />
        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Players_Statistics_StatisticID",
                table: "Players");

            migrationBuilder.DropForeignKey(
                name: "FK_Players_Teams_TeamID",
                table: "Players");

            migrationBuilder.DropColumn(
                name: "PlyrDOB",
                table: "Players");

            migrationBuilder.RenameColumn(
                name: "StatisticID",
                table: "Players",
                newName: "StatisticsID");

            migrationBuilder.RenameIndex(
                name: "IX_Players_StatisticID",
                table: "Players",
                newName: "IX_Players_StatisticsID");

            migrationBuilder.AddColumn<int>(
                name: "StatsID",
                table: "Players",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AlterColumn<DateTime>(
                name: "GameStartTime",
                table: "Games",
                type: "TEXT",
                nullable: false,
                defaultValue: new DateTime(1, 1, 1, 0, 0, 0, 0, DateTimeKind.Unspecified),
                oldClrType: typeof(DateTime),
                oldType: "TEXT",
                oldNullable: true);

            migrationBuilder.AddForeignKey(
                name: "FK_Players_Statistics_StatisticsID",
                table: "Players",
                column: "StatisticsID",
                principalTable: "Statistics",
                principalColumn: "ID");

            migrationBuilder.AddForeignKey(
                name: "FK_Players_Teams_TeamID",
                table: "Players",
                column: "TeamID",
                principalTable: "Teams",
                principalColumn: "ID",
                onDelete: ReferentialAction.Cascade);
        }
    }
}
