﻿using System.ComponentModel;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace wmbaApp.Models
{
    public class Lineup
    {
        public int ID { get; set; }

       
        [Display(Name = "Home Teams")]
        public int HomeTeamID { get; set; }
        public Team HomeTeam { get; set; }

        [Display(Name = "Away Teams")]
        public int AwayTeamID { get; set; }
        public Team AwayTeam { get; set; }

        public ICollection<LineupPlayer> LineupPlayers { get; set; } = new HashSet<LineupPlayer>();


        [Display(Name = "Game")]
        public ICollection<Game> Games { get; set; } = new HashSet<Game>();
    }
}
