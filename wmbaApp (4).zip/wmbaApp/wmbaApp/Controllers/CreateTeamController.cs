﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Numerics;
using wmbaApp.CustomControllers;
using wmbaApp.Data;
using wmbaApp.Models;

namespace wmbaApp.Controllers
{
    public class CreateTeamController : ElephantController
    {
        private readonly WmbaContext _context;

        public CreateTeamController(WmbaContext context)
        {
            _context = context;
        }
        public IActionResult CreateNewTeam()
        {
            var team = new Team();
            return View(team);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateNewTeam([Bind("ID,TmName,TmAbbreviation,DivisionID")] Team team)
        {
            if (ModelState.IsValid)
            {
                // Saves team details to TempData or Session
                TempData["Team"] = team;
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(CreatePlayers));
            }

            return View(team);
        }

        public IActionResult CreatePlayers()
        {
            // Retrieves team details from TempData or Session
            var team = TempData["Team"] as Team;
            if (team == null)
            {
                // Handles the case where TempData is not available
                return RedirectToAction(nameof(CreateDivisionTeam));
            }

            var player = new Player();
            return View(player);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreatePlayers([Bind("ID,PlyrFirstName,PlyrLastName,PlyrJerseyNumber,TmID,StatsID")] Player player)
        {
            if (ModelState.IsValid)
            {
                // Saves player details to TempData or Session
                TempData["Player"] = player;
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            return View(player);
        }

        public IActionResult CreateDivisionTeam()
        {
            // Retrieves team and player details from TempData or Session
            var team = TempData["Team"] as Team;
            var player = TempData["Player"] as Player;

            if (team == null || player == null)
            {

                // Handles the case where TempData is not available
                return RedirectToAction(nameof(CreateNewTeam));
            }

            var division = new Division();
            return View(division);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> CreateDivisionTeam([Bind("ID,DivName")] Division division)
        {
            if (ModelState.IsValid)
            {
                // Saves division details to TempData or Session
                TempData["Division"] = division;
                await _context.SaveChangesAsync();
                // Performs the final steps or redirect to a summary page
                return RedirectToAction(nameof(Summary));
            }

            return View(division);
        }

        public IActionResult Summary()
        {
            // Retrieves team, player, and division details from TempData or Session
            var team = TempData["Team"] as Team;
            var player = TempData["Player"] as Player;
            var division = TempData["Division"] as Division;

            if (team == null || player == null || division == null)
            {
                // Handles the case where TempData is not available or data is missing
                return RedirectToAction(nameof(CreateNewTeam));
            }

            // Displaya a summary of the entered data
            return View();
        }
    }

}
