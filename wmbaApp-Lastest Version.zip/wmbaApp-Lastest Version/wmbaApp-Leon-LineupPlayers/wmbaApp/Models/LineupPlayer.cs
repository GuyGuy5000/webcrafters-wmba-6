﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;

namespace wmbaApp.Models
{
    /// <summary>
    /// Conjunction table for Lineup and the Players
    /// Farooq Jidelola
    /// </summary>
    public class LineupPlayer
    {
        [Key]
        public int Id { get; set; }

        [ForeignKey("LineupID")]
        public int LineupID { get; set; }
        public Lineup Lineup { get; set; }


        public int? HomePlayerID { get; set; }
        [ForeignKey("HomePlayerID")]
        public Player HomePlayer { get; set; }



        public int? AwayPlayerID { get; set; }
        [ForeignKey("AwayPlayerID")]
        public Player AwayPlayer { get; set; }
    }
}
