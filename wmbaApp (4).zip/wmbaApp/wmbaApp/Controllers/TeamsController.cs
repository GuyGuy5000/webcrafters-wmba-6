﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using wmbaApp.Data;
using Team = wmbaApp.Models.Team;
using static System.Runtime.InteropServices.JavaScript.JSType;
using wmbaApp.CustomControllers;
using wmbaApp.Utilities;
using wmbaApp.ViewModels;
using Microsoft.EntityFrameworkCore.Storage;
using System.Numerics;
using Microsoft.AspNetCore.Authorization;
using wmbaApp.Models;

namespace wmbaApp.Controllers
{
    public class TeamsController : ElephantController
    {
        private readonly WmbaContext _context;

        public TeamsController(WmbaContext context)
        {
            _context = context;
        }

        // GET: Teams
        public async Task<IActionResult> Index(string SearchString, int? DivisionID,
             int? page, int? pageSizeID, string actionButton, string sortDirection = "asc", string sortField = "Team")
        {
            //Count the number of filters applied - start by assuming no filters
            ViewData["Filtering"] = "btn-outline-secondary";
            int numberFilters = 0;
            //Then in each "test" for filtering, add to the count of Filters applied

            //List of sort options.
            //NOTE: make sure this array has matching values to the column headings
            string[] sortOptions = new[] { "Team Name", "Team ABBR", "Team Division", "Division Coaches", "Players" };
            PopulateDropDownLists();

            var teams = _context.Teams

            .Include(t => t.Division)
            .Include(t => t.DivisionCoaches).ThenInclude(t => t.Coach)
           .Include(t => t.Players).Include(t => t.Players)
           .Include(t => t.GameTeams).ThenInclude(t => t.Game)
           .AsNoTracking();

            //Add as many filters as needed
            if (DivisionID.HasValue)
            {
                teams = teams.Where(t => t.DivisionID == DivisionID);
                numberFilters++;
            }

            if (!System.String.IsNullOrEmpty(SearchString))
            {
                teams = teams.Where(p => p.TmName.ToUpper().Contains(SearchString.ToUpper())
                                       || p.TmAbbreviation.ToUpper().Contains(SearchString.ToUpper())
                                       );

                numberFilters++;
            }
            //Give feedback about the state of the filters
            if (numberFilters != 0)
            {
                //Toggle the Open/Closed state of the collapse depending on if we are filtering
                ViewData["Filtering"] = " btn-danger";
                //Show how many filters have been applied
                ViewData["numberFilters"] = "(" + numberFilters.ToString()
                    + " Filter" + (numberFilters > 1 ? "s" : "") + " Applied)";
                //Keep the Bootstrap collapse open
                //@ViewData["ShowFilter"] = " show";
            }

            //Before we sort, see if we have called for a change of filtering or sorting
            if (!System.String.IsNullOrEmpty(actionButton)) //Form Submitted!
            {
                page = 1;//Reset page to start

                if (sortOptions.Contains(actionButton))//Change of sort is requested
                {
                    if (actionButton == sortField) //Reverse order on same field
                    {
                        sortDirection = sortDirection == "asc" ? "desc" : "asc";
                    }
                    sortField = actionButton;//Sort by the button clicked
                }
            }
            //Now we know which field and direction to sort by
            if (sortField == "Team Name")
            {

                if (sortDirection == "asc")
                {
                    teams = teams
                        .OrderBy(p => p.TmName);
                }
                else
                {
                    teams = teams
                        .OrderByDescending(p => p.TmName);
                }
            }
            else if (sortField == "Team ABBR")
            {
                if (sortDirection == "asc")
                {
                    teams = teams
                      .OrderBy(p => p.TmAbbreviation);
                }
                else
                {
                    teams = teams
                       .OrderByDescending(p => p.TmAbbreviation);

                }
            }
            else 
            {
                if (sortDirection == "asc")
                {
                    teams = teams
                       .OrderBy(p => p.Division);

                }
                else
                {
                    teams = teams
                       .OrderByDescending(p => p.Division);

                }
            }



            //Set sort for next time
            ViewData["sortField"] = sortField;
            ViewData["sortDirection"] = sortDirection;

            int pageSize = PageSizeHelper.SetPageSize(HttpContext, pageSizeID, ControllerName());
            ViewData["pageSizeID"] = PageSizeHelper.PageSizeList(pageSize);
            var pagedData = await PaginatedList<Team>.CreateAsync(teams.AsNoTracking(), page ?? 1, pageSize);

            // Change the return statement to use the pagedData
            return View(pagedData);

        }
   

        // GET: Teams/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Teams == null)
            {
                return NotFound();
            }

           var teams = await _context.Teams
           .Include(t => t.Division)
           .Include(t => t.DivisionCoaches).ThenInclude(dr => dr.Coach)
           .Include(t => t.Players)
           .Include(t => t.GameTeams).ThenInclude(dr => dr.Game)
           .AsNoTracking()
           .FirstOrDefaultAsync(m => m.ID == id);
            if (teams == null)
            {
                return NotFound();
            }

            return View(teams);
        }

        // GET: Teams/Create
        public IActionResult Create()
        {
       

        Team team = new Team();
        PopulateDropDownLists(team);
        PopulateAssignedPlayersCheckboxes(team);
        PopulateAssignedDivisionCoachesCheckboxes(team);
        //PopulateAssignedGamesCheckboxes(team);
            return View(team);
    }

        // POST: Teams/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,TmName,TmAbbreviation,DivisionID, DivisionCoaches, Players, GameTeams")] 
        Team team, string[] selectedOptions)
        {
            try
            {
                //Add the selected conditions
                if (selectedOptions != null)
                {
                    foreach (var condition in selectedOptions)
                    {
                        var divisionCoachToAdd = new DivisionCoach { DivisionID = team.ID, CoachID = int.Parse(condition) };
                        team.DivisionCoaches.Add(divisionCoachToAdd);
                    }
                }
                if (selectedOptions != null)
                {
                    foreach (var condition in selectedOptions)
                    {
                        var playerToAdd = new Player { ID = team.ID };
                        team.Players.Add(playerToAdd);
                    }
                }
                if (selectedOptions != null)
                {
                    foreach (var condition in selectedOptions)
                    {
                        var gameToAdd = new GameTeam { GameID = team.ID };
                        team.GameTeams.Add(gameToAdd);
                    }
                }
                if (ModelState.IsValid)
                {
                    _context.Add(team);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("Details", new { team.ID });
                }
               
            }
            catch (RetryLimitExceededException /* dex */)
            {
                ModelState.AddModelError("", "Unable to save changes after multiple attempts. Try again, and if the problem persists, see your system administrator.");
            }
            catch (DbUpdateException)
            {
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }

            PopulateDropDownLists(team);
       
            PopulateAssignedPlayersCheckboxes(team);
            //PopulateAssignedGamesCheckboxes(team);
            PopulateAssignedDivisionCoachesCheckboxes(team);
            return View(team);
        }

        // GET: Teams/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Teams == null)
            {
                return NotFound();
            }

            var teams = await _context.Teams
            .Include(t => t.Division)
            .Include(t => t.DivisionCoaches).ThenInclude(dr => dr.Coach)
            .Include(t => t.Players)
            .Include(t => t.GameTeams).ThenInclude(dr => dr.Game)
            .AsNoTracking()
            .FirstOrDefaultAsync(m => m.ID == id);
            if (teams == null)
            {
                return NotFound();
            }
            PopulateDropDownLists(teams);
            PopulateAssignedPlayersCheckboxes(teams);
            PopulateAssignedDivisionCoachesCheckboxes(teams);
            //PopulateAssignedGamesCheckboxes(teams);
            return View(teams);
        }

        // POST: Teams/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, string[] selectedOptions)
        {

            var teamsToUpdate = await _context.Teams
            .Include(t => t.Division)
            .Include(t => t.DivisionCoaches).ThenInclude(dr => dr.Coach)
            .Include(t => t.Players)
            .Include(t => t.GameTeams).ThenInclude(dr => dr.Game)
            .FirstOrDefaultAsync(m => m.ID == id);

            if (teamsToUpdate == null)
            {
                return NotFound();
            }

            UpdateDivisionCoachesListboxes(selectedOptions, teamsToUpdate);
            UpdateFunctionPlayersListboxes(selectedOptions, teamsToUpdate);
            UpdateFunctionGameTeamsListboxes(selectedOptions, teamsToUpdate);


            if (await TryUpdateModelAsync<Team>(teamsToUpdate, "",
                t => t.TmName, t => t.TmAbbreviation, t => t.DivisionID, t => t.DivisionCoaches, 
                t => t.Players, t => t.GameTeams ))
            {
                try
                {
                    _context.Update(teamsToUpdate);
                    await _context.SaveChangesAsync();
                    return RedirectToAction("Details", new { teamsToUpdate.ID });
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!TeamExists(teamsToUpdate.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                catch (DbUpdateException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
                PopulateDropDownLists(teamsToUpdate);
                PopulatePlayersLists(teamsToUpdate);
                PopulateDivisionCoachesLists(teamsToUpdate);
                PopulateFunctionGameTeamsLists(teamsToUpdate);
                return View(teamsToUpdate);
            }
            return View(teamsToUpdate);
        }

        // GET: Teams/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Teams == null)
            {
                return NotFound();
            }

            var team = await _context.Teams
             .Include(t => t.Division)
             .Include(t => t.DivisionCoaches).ThenInclude(dr => dr.Coach)
             .Include(t => t.Players)
             .Include(t => t.GameTeams).ThenInclude(dr => dr.Game)
             .AsNoTracking()
             .FirstOrDefaultAsync(m => m.ID == id);
            if (team == null)
            {
                return NotFound();
            }

            return View(team);
        }

        // POST: Teams/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Teams == null)
            {
                return Problem("Entity set 'teams.Teams'  is null.");
            }
            var team = await _context.Teams
              .Include(t => t.Division)
              .Include(t => t.DivisionCoaches).ThenInclude(dr => dr.Coach)
              .Include(t => t.Players)
              .Include(t => t.GameTeams).ThenInclude(dr => dr.Game)
              .FirstOrDefaultAsync(m => m.ID == id);
            try
            {
                if (team != null)
                {
                    _context.Teams.Remove(team);
                }

                await _context.SaveChangesAsync();
                return Redirect(ViewData["returnURL"].ToString());
            }
            catch (DbUpdateException)
            {
                //Note: there is really no reason a delete should fail if you can "talk" to the database.
                ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
            }

            return View(team);
        }

        //Note that we will use checkbox approach for create.
        #region Maintain Checkboxes
        
        private void PopulateAssignedDivisionCoachesCheckboxes(Team team)
        {
            //For this to work, you must have Included the FunctionRooms 
            //in the Function
            var allOptions = _context.Coaches;
          
           
            var currentOptionIDs = new HashSet<int>(team.DivisionCoaches.Select(b => b.CoachID));
        

            var checkBoxes = new List<CheckOptionVM>();
            foreach (var option in allOptions)
            {
                checkBoxes.Add(new CheckOptionVM
                {
                    ID = option.ID,
                    DisplayText = option.FullName,
                    Assigned = currentOptionIDs.Contains(option.ID)
                });
            }
            ViewData["CoachOptions"] = checkBoxes;
        }
        //Note: we are not using UpdateFunctionRoomCheckboxes becuase we don
        //not need it for Create and we are going to demo the Two Listbox approach
        //for Edit.  However, the code is still here for reference.
        private void UpdateDivisionCoachesCheckboxes(string[] selectedOptions, Team teamsToUpdate)
        {
            if (selectedOptions == null)
            {
                teamsToUpdate.DivisionCoaches = new List<DivisionCoach>();
                return;
            }

            var selectedOptionsHS = new HashSet<string>(selectedOptions);
            var teamOptionsHS = new HashSet<int>
                (teamsToUpdate.DivisionCoaches.Select(c => c.CoachID));//IDs of the currently selected conditions
            foreach (var option in _context.Coaches)
            {
                if (selectedOptionsHS.Contains(option.ID.ToString())) //It is checked
                {
                    if (!teamOptionsHS.Contains(option.ID))  //but not currently in the history
                    {
                        teamsToUpdate.DivisionCoaches.Add(new DivisionCoach { DivisionID = teamsToUpdate.ID, CoachID = option.ID });
                    }
                }
                else
                {
                    //Checkbox Not checked
                    if (teamOptionsHS.Contains(option.ID)) //but it is currently in the history - so remove it
                    {
                        DivisionCoach conditionToRemove = teamsToUpdate.DivisionCoaches.SingleOrDefault(c => c.CoachID == option.ID);
                        _context.Remove(conditionToRemove);
                    }
                }
            }
        }
        #endregion



        #region Maintain Checkboxes
        private void PopulateAssignedPlayersCheckboxes(Team team)
        {
            //For this to work, you must have Included the FunctionRooms 
            //in the Function
            var allChoices = _context.Players;



            var currentOptionID = new HashSet<int>(team.Players.Select(b => b.ID));



            var checkBoxes = new List<CheckOptionVM>();
            foreach (var option in allChoices)
            {
                checkBoxes.Add(new CheckOptionVM
                {
                    ID = option.ID,
                    DisplayText = option.FullName,
                    Assigned = currentOptionID.Contains(option.ID)
                });
            }
            ViewData["PlayerOptions"] = checkBoxes;
        }

        private void UpdateFunctionPlayersCheckboxes(string[] selectedOptions, Team teamsToUpdate)
        {
            if (selectedOptions == null)
            {
                teamsToUpdate.Players = new List<Player>();
                return;
            }

            var selectedOptionsHS = new HashSet<string>(selectedOptions);
            var teamOptionsHS = new HashSet<int>
                (teamsToUpdate.Players.Select(c => c.ID));//IDs of the currently selected conditions
            foreach (var option in _context.Players)
            {
                if (selectedOptionsHS.Contains(option.ID.ToString())) //It is checked
                {
                    if (!teamOptionsHS.Contains(option.ID))  //but not currently in the history
                    {
                        teamsToUpdate.Players.Add(new Player { ID = teamsToUpdate.ID });
                    }
                }
                else
                {
                    //Checkbox Not checked
                    if (teamOptionsHS.Contains(option.ID)) //but it is currently in the history - so remove it
                    {
                        Player conditionToRemove = teamsToUpdate.Players.SingleOrDefault(c => c.ID == option.ID);
                        _context.Remove(conditionToRemove);
                    }
                }
            }
        }
        #endregion










        #region Maintain Checkboxes
        private void PopulateAssignedGamesCheckboxes(Team team)
        {
            //For this to work, you must have Included the FunctionRooms 
            //in the Function

            var allOpts = _context.GameTeams;

            var currentOptIDs = new HashSet<int>(team.GameTeams.Select(b => b.GameID));
            var checkBoxes = new List<CheckOptionVM>();
            foreach (var option in allOpts)
            {
                checkBoxes.Add(new CheckOptionVM
                {
                    ID = option.GameID,
                    DisplayText = option.Game.Duration,
                    Assigned = currentOptIDs.Contains(option.GameID)
                });
            }
            ViewData["GameOptions"] = checkBoxes;
        }

        private void UpdateFunctionGamesCheckboxes(string[] selectedOptions, Team teamsToUpdate)
        {
            if (selectedOptions == null)
            {
                teamsToUpdate.GameTeams = new List<GameTeam>();
                return;
            }

            var selectedOptionsHS = new HashSet<string>(selectedOptions);
            var teamOptionsHS = new HashSet<int>
                (teamsToUpdate.GameTeams.Select(c => c.TeamID));//IDs of the currently selected conditions
            foreach (var option in _context.GameTeams)
            {
                if (selectedOptionsHS.Contains(option.TeamID.ToString())) //It is checked
                {
                    if (!teamOptionsHS.Contains(option.TeamID))  //but not currently in the history
                    {
                        teamsToUpdate.GameTeams.Add(new GameTeam { TeamID = teamsToUpdate.ID });
                    }
                }
                else
                {
                    //Checkbox Not checked
                    if (teamOptionsHS.Contains(option.TeamID)) //but it is currently in the history - so remove it
                    {
                        GameTeam conditionToRemove = teamsToUpdate.GameTeams.SingleOrDefault(c => c.TeamID == option.Team.ID);
                        _context.Remove(conditionToRemove);
                    }
                }
            }
        }
        #endregion


        #region Maintain ListBoxes

        private void PopulateDivisionCoachesLists(Team team)
        {
            //For this to work, you must have Included the child collection in the parent object
            var allOptions = _context.Coaches;
            var currentOptionsHS = new HashSet<int>(team.DivisionCoaches.Select(b => b.CoachID));
            //Instead of one list with a boolean, we will make two lists
            var selected = new List<ListOptionVM>();
            var available = new List<ListOptionVM>();
            foreach (var r in allOptions)
            {
                if (currentOptionsHS.Contains(r.ID))
                {
                    selected.Add(new ListOptionVM
                    {
                        ID = r.ID,
                        DisplayText = r.FullName
                    });
                }
                else
                {
                    available.Add(new ListOptionVM
                    {
                        ID = r.ID,
                        DisplayText = r.FullName
                    });
                }
            }

            ViewData["selOpts"] = new MultiSelectList(selected.OrderBy(s => s.DisplayText), "ID", "DisplayText");
            ViewData["availOpts"] = new MultiSelectList(available.OrderBy(s => s.DisplayText), "ID", "DisplayText");
        }
        private void UpdateDivisionCoachesListboxes(string[] selectedOptions, Team teamToUpdate)
        {
            if (selectedOptions == null)
            {
                teamToUpdate.DivisionCoaches = new List<DivisionCoach>();
                return;
            }

            var selectedOptionsHS = new HashSet<string>(selectedOptions);
            var currentOptionsHS = new HashSet<int>(teamToUpdate.DivisionCoaches.Select(b => b.CoachID));
            foreach (var r in _context.Coaches)
            {
                if (selectedOptionsHS.Contains(r.ID.ToString()))//it is selected
                {
                    if (!currentOptionsHS.Contains(r.ID))//but not currently in the Function's collection - Add it!
                    {
                        teamToUpdate.DivisionCoaches.Add(new DivisionCoach
                        {
                            CoachID = r.ID,
                            DivisionID = teamToUpdate.ID
                        });
                    }
                }
                else //not selected
                {
                    if (currentOptionsHS.Contains(r.ID))//but is currently in the Function's collection - Remove it!
                    {
                        DivisionCoach coachToRemove = teamToUpdate.DivisionCoaches.FirstOrDefault(d => d.CoachID == r.ID);
                        _context.Remove(coachToRemove);
                    }
                }
            }
        }
        #endregion



        #region Maintain ListBoxes

        private void PopulatePlayersLists(Team team)
        {
            //For this to work, you must have Included the child collection in the parent object
            var allOptions = _context.Coaches;
            var currentOptionsHS = new HashSet<int>(team.Players.Select(b => b.ID));
            //Instead of one list with a boolean, we will make two lists
            var selected = new List<ListOptionVM>();
            var available = new List<ListOptionVM>();
            foreach (var r in allOptions)
            {
                if (currentOptionsHS.Contains(r.ID))
                {
                    selected.Add(new ListOptionVM
                    {
                        ID = r.ID,
                        DisplayText = r.FullName
                    });
                }
                else
                {
                    available.Add(new ListOptionVM
                    {
                        ID = r.ID,
                        DisplayText = r.FullName
                    });
                }
            }

            ViewData["selOpts"] = new MultiSelectList(selected.OrderBy(s => s.DisplayText), "ID", "DisplayText");
            ViewData["availOpts"] = new MultiSelectList(available.OrderBy(s => s.DisplayText), "ID", "DisplayText");
        }
        private void UpdateFunctionPlayersListboxes(string[] selectedOptions, Team teamToUpdate)
        {
            if (selectedOptions == null)
            {
                teamToUpdate.Players = new List<Player>();
                return;
            }

            var selectedOptionsHS = new HashSet<string>(selectedOptions);
            var currentOptionsHS = new HashSet<int>(teamToUpdate.Players.Select(b => b.ID));
            foreach (var r in _context.Players)
            {
                if (selectedOptionsHS.Contains(r.ID.ToString()))//it is selected
                {
                    if (!currentOptionsHS.Contains(r.ID))//but not currently in the Function's collection - Add it!
                    {
                        teamToUpdate.Players.Add(new Player
                        {
                            ID = r.ID,
                            TmID = teamToUpdate.ID
                        });
                    }
                }
                else //not selected
                {
                    if (currentOptionsHS.Contains(r.ID))//but is currently in the Function's collection - Remove it!
                    {
                        Player playerToRemove = teamToUpdate.Players.FirstOrDefault(d => d.ID == r.ID);
                        _context.Remove(playerToRemove);
                    }
                }
            }
        }
        #endregion



        #region Maintain ListBoxes

        private void PopulateFunctionGameTeamsLists(Team team)
        {
            //For this to work, you must have Included the child collection in the parent object
            var allOptions = _context.GameTeams;
            var currentOptionsHS = new HashSet<int>(team.GameTeams.Select(b => b.GameID));
            //Instead of one list with a boolean, we will make two lists
            var selected = new List<ListOptionVM>();
            var available = new List<ListOptionVM>();
            foreach (var r in allOptions)
            {
                if (currentOptionsHS.Contains(r.GameID))
                {
                    selected.Add(new ListOptionVM
                    {
                        ID = r.GameID,
                        DisplayText = r.Game.Summary
                    });
                }
                else
                {
                    available.Add(new ListOptionVM
                    {
                        ID = r.GameID,
                        DisplayText = r.Game.Summary
                    });
                }
            }

            ViewData["selOpts"] = new MultiSelectList(selected.OrderBy(s => s.DisplayText), "ID", "DisplayText");
            ViewData["availOpts"] = new MultiSelectList(available.OrderBy(s => s.DisplayText), "ID", "DisplayText");
        }
        private void UpdateFunctionGameTeamsListboxes(string[] selectedOptions, Team teamToUpdate)
        {
            if (selectedOptions == null)
            {
                teamToUpdate.GameTeams = new List<GameTeam>();
                return;
            }

            var selectedOptionsHS = new HashSet<string>(selectedOptions);
            var currentOptionsHS = new HashSet<int>(teamToUpdate.Players.Select(b => b.ID));
            foreach (var r in _context.GameTeams)
            {
                if (selectedOptionsHS.Contains(r.TeamID.ToString()))//it is selected
                {
                    if (!currentOptionsHS.Contains(r.TeamID))//but not currently in the Function's collection - Add it!
                    {
                        teamToUpdate.GameTeams.Add(new GameTeam
                        {
                            TeamID = r.TeamID,
                            GameID = teamToUpdate.ID
                        });
                    }
                }
                else //not selected
                {
                    if (currentOptionsHS.Contains(r.TeamID))//but is currently in the Function's collection - Remove it!
                    {
                        GameTeam gameToRemove = teamToUpdate.GameTeams.FirstOrDefault(d => d.TeamID == r.TeamID);
                        _context.Remove(gameToRemove);
                    }
                }
            }
        }
        #endregion


        [HttpGet]
        public JsonResult GetDivision(int? id)
        {
            return Json(DivisionSelectList(id));
        }

        private SelectList DivisionSelectList(int? selectedId)
       {
        return new SelectList(_context.Divisions, "ID", "DivName", selectedId);
       }
    private void PopulateDropDownLists(Team team = null)
    {
        ViewData["DivisionID"] = DivisionSelectList(team?.DivisionID);
       
    }
    private bool TeamExists(int id)
        {
          return _context.Teams.Any(e => e.ID == id);
        }
    }
}

