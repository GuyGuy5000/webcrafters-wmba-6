﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using wmbaApp.Data;
using wmbaApp.Models;
using static System.Runtime.InteropServices.JavaScript.JSType;
using wmbaApp.Utilities;
using wmbaApp.CustomControllers;
using Microsoft.EntityFrameworkCore.Storage;

namespace wmbaApp.Controllers
{
    public class GamesController : ElephantController
    {
        private readonly WmbaContext _context;

        public GamesController(WmbaContext context)
        {
            _context = context;
        }

        // GET: Games
        public async Task<IActionResult> Index(string SearchString, int? DivisionID,
             int? page, int? pageSizeID, string actionButton, string sortDirection = "asc", string sortField = "")
        {
            //Gets matchups from teams query
            var teams = _context.Teams
                .Include(t => t.Division)
                .Include(t => t.DivisionCoaches).ThenInclude(t => t.Coach)
                .Include(t => t.Players)
                .Include(t => t.GameTeams).ThenInclude(t => t.Game)
                .AsNoTracking();
            List<GameMatchup> matchups = GameMatchup.GetMatchups(_context, teams.ToArray());
            ViewData["Matchups"] = matchups;

            ViewData["Filtering"] = "btn-outline-secondary";
            int numberFilters = 0;
            //Then in each "test" for filtering, add to the count of Filters applied

            //List of sort options.
            //NOTE: make sure this array has matching values to the column headings
            string[] sortOptions = new[] { "Game Matchup", "Start Time", "Start Time", "Location" };
            var games = _context.Games
                .Include(g => g.GameTeams).ThenInclude(g => g.Team)
                .AsNoTracking();
            ;
            if (!System.String.IsNullOrEmpty(SearchString))
            {
                //filter through matchups
                int[] gameIDs = matchups.Where(m => m.FullVersus.ToUpper().Contains(SearchString.ToUpper())
                                                 || m.AbbreviationVersus.ToUpper().Contains(SearchString.ToUpper()))
                                        .Select(m => m.game.ID)
                                        .ToArray();

                games = games.Where(g => gameIDs.Contains(g.ID) //get all games that have a matchup
                                      || g.GameLocation.ToUpper().Contains(SearchString.ToUpper()));//get all games that match location
                numberFilters++;
            }
            if (!System.String.IsNullOrEmpty(actionButton)) //Form Submitted!
            {
                page = 1;//Reset page to start

                if (sortOptions.Contains(actionButton))//Change of sort is requested
                {
                    if (actionButton == sortField) //Reverse order on same field
                    {
                        sortDirection = sortDirection == "asc" ? "desc" : "asc";
                    }
                    sortField = actionButton;//Sort by the button clicked
                }
            }
            if (numberFilters != 0)
            {
                //Toggle the Open/Closed state of the collapse depending on if we are filtering
                ViewData["Filtering"] = " btn-danger";
                //Show how many filters have been applied
                ViewData["numberFilters"] = "(" + numberFilters.ToString()
                    + " Filter" + (numberFilters > 1 ? "s" : "") + " Applied)";
            }

            if (sortField == "Game Matchup")
            {

                if (sortDirection == "asc")
                {
                    games = games
                        .OrderBy(p => p.GameStartTime);
                }
                else
                {
                    games = games
                        .OrderByDescending(p => p.GameStartTime);
                }
            }
            else if (sortField == "Start Time")
            {

                if (sortDirection == "asc")
                {
                    games = games
                        .OrderBy(p => p.GameStartTime);
                }
                else
                {
                    games = games
                        .OrderByDescending(p => p.GameStartTime);
                }
            }
            else if (sortField == "Start Time")
            {
                if (sortDirection == "asc")
                {
                    games = games
                      .OrderBy(p => p.GameEndTime);
                }
                else
                {
                    games = games
                       .OrderByDescending(p => p.GameEndTime);
                }
            }
            else if (sortField == "Location")
            {
                if (sortDirection == "asc")
                {
                    games = games
                       .OrderBy(p => p.GameLocation);

                }
                else
                {
                    games = games
                       .OrderByDescending(p => p.GameLocation);

                }
            }
            ViewData["sortField"] = sortField;
            ViewData["sortDirection"] = sortDirection;

            int pageSize = PageSizeHelper.SetPageSize(HttpContext, pageSizeID, ControllerName());
            ViewData["pageSizeID"] = PageSizeHelper.PageSizeList(pageSize);
            var pagedData = await PaginatedList<Game>.CreateAsync(games.AsNoTracking(), page ?? 1, pageSize);

            return View(pagedData);
        }

        // GET: Games/Details/5
        public async Task<IActionResult> Details(int? id)
        {
            if (id == null || _context.Games == null)
            {
                return NotFound();
            }

            var game = await _context.Games
                .FirstOrDefaultAsync(m => m.ID == id);
            if (game == null)
            {
                return NotFound();
            }

            return View(game);
        }

        // GET: Games/Create
        public IActionResult Create()
        {
            PopulateDropDownLists();

            return View();
        }

        // POST: Games/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,GameStartTime,GameEndTime,GameLocation")] Game game, int? HomeTeamID, int? AwayTeamID)
        {
            PopulateDropDownLists();
            if (ModelState.IsValid)
            {
                try
                {
                    CreateGameTeams(HomeTeamID, AwayTeamID, game);
                    _context.Add(game);
                    await _context.SaveChangesAsync();
                    return RedirectToAction(nameof(Index));
                }
                catch (RetryLimitExceededException /* dex */)
                {
                    ModelState.AddModelError("", "Unable to save changes after multiple attempts. Try again, and if the problem persists, see your system administrator.");
                }
                catch (DbUpdateException)
                {
                    ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                }
            }
            return View(game);
        }

        // GET: Games/Edit/5
        public async Task<IActionResult> Edit(int? id)
        {
            if (id == null || _context.Games == null)
            {
                return NotFound();
            }

            var game = await _context.Games
                .Include(g => g.GameTeams).ThenInclude(g => g.Team)
                .FirstOrDefaultAsync(g => g.ID == id);

            if (game == null)
            {
                return NotFound();
            }
            PopulateDropDownLists(game.GameTeams.ToArray());
            return View(game);
        }

        // POST: Games/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int? id, int? HomeTeamID, int? AwayTeamID)
        {

            var gameToUpdate = await _context.Games
                .Include(g => g.GameTeams).ThenInclude(g => g.Team)
                .FirstOrDefaultAsync(g => g.ID == id);

            if (gameToUpdate == null)
            {
                return NotFound();
            }
            PopulateDropDownLists(gameToUpdate.GameTeams.ToArray());

            GameMatchup matchup = new GameMatchup(_context, gameToUpdate.GameTeams.First());

            if (await TryUpdateModelAsync<Game>(gameToUpdate, "",
                g => g.GameStartTime, g => g.GameEndTime, g => g.GameLocation))
            {
                if (ModelState.IsValid)
                {
                    try
                    {
                        _context.Update(gameToUpdate);
                        await _context.SaveChangesAsync();
                        return RedirectToAction(nameof(Index));
                    }
                    catch (RetryLimitExceededException /* dex */)
                    {
                        ModelState.AddModelError("", "Unable to save changes after multiple attempts. Try again, and if the problem persists, see your system administrator.");
                    }
                    catch (DbUpdateException)
                    {
                        ModelState.AddModelError("", "Unable to save changes. Try again, and if the problem persists see your system administrator.");
                    }
                }
            }
            return View(gameToUpdate);
        }

        // GET: Games/Delete/5
        public async Task<IActionResult> Delete(int? id)
        {
            if (id == null || _context.Games == null)
            {
                return NotFound();
            }

            var game = await _context.Games
                .Include(g => g.GameTeams).ThenInclude(g => g.Team)
                .FirstOrDefaultAsync(g => g.ID == id);

            if (game == null)
            {
                return NotFound();
            }

            return View(game);
        }

        // POST: Games/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id)
        {
            if (_context.Games == null)
            {
                return Problem("Entity set 'WmbaContext.Games'  is null.");
            }
            var game = await _context.Games.FindAsync(id);
            var GameTeam = await _context.GameTeams.Where(x => x.GameID == game.ID).ToListAsync();

            if (game != null)
            {
                _context.Games.Remove(game);
            }

            await _context.SaveChangesAsync();
            return RedirectToAction(nameof(Index));
        }

        #region SelectLists
        private SelectList HomeTeamSelectList(int? selectedId)
        {
            return new SelectList(_context.Teams, "ID", "TmName", selectedId);
        }
        private SelectList AwayTeamSelectList(int? selectedId)
        {
            return new SelectList(_context.Teams, "ID", "TmName", selectedId);
        }
        private void PopulateDropDownLists(GameTeam[] gameTeam = null)
        {
            if (gameTeam != null)
            {
                if (gameTeam[0] != null)
                    ViewData["HomeTeamID"] = HomeTeamSelectList(gameTeam[0]?.TeamID);
                if (gameTeam[1] != null)
                    ViewData["AwayTeamID"] = AwayTeamSelectList(gameTeam[1]?.TeamID);
            }
            else
            {
                ViewData["HomeTeamID"] = HomeTeamSelectList(null);
                ViewData["AwayTeamID"] = AwayTeamSelectList(null);
            }
        }
        #endregion

        #region gameTeams
        public void CreateGameTeams(int? HomeTeamID, int? AwayTeamID, Game gameToUpdate)
        {
            if (HomeTeamID == AwayTeamID)
            {
                ModelState.AddModelError("", "A team cannot be matched against itself. Please select two different teams.");
            }

            if (HomeTeamID != null)
            {
                var teamToAdd = new GameTeam { GameID = gameToUpdate.ID, TeamID = (int)HomeTeamID, GmtmLineup = "TBA" };
                gameToUpdate.GameTeams.Add(teamToAdd);
            }

            if (AwayTeamID != null)
            {
                var teamToAdd = new GameTeam { GameID = gameToUpdate.ID, TeamID = (int)AwayTeamID, GmtmLineup = "TBA" };
                gameToUpdate.GameTeams.Add(teamToAdd);
            }
        }
        #endregion

        private bool GameExists(int id)
        {
            return _context.Games.Any(e => e.ID == id);
        }
    }
}
