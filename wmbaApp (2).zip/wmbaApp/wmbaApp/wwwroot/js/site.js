﻿// Please see documentation at https://docs.microsoft.com/aspnet/core/client-side/bundling-and-minification
// for details on configuring this project to bundle and minify static web assets.
// Done By: Emmanuel James
// Last Modified: 2024/01/23
// Write your JavaScript code.

function confirmMakeInactive(teamId) {
    // Show a confirmation dialog
    var isConfirmed = confirm("Are you sure you want to make this team inactive?");

    // If the user clicks "OK," proceed with making the team inactive
    if (isConfirmed) {
        // Construct the button ID for the specific row
        var buttonId = "actions_" + teamId;

        // Get the button element
        var deactivate = document.getElementById(buttonId);

        // Update the button style to hide it
        deactivate.style.display = 'none';

        // Redirect to the MakeInactive action
        window.location.href = '/Teams/MakeInactive/' + teamId;
    }
}

