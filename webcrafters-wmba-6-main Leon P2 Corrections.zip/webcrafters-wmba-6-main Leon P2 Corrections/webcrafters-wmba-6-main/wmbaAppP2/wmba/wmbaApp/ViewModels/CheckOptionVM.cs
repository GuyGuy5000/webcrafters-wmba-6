﻿namespace wmbaApp.ViewModels
{
    public class CheckOptionVM
    {
        //Used for a Checkbox
        public int ID { get; set; }
        public string DisplayText { get; set; }
        public bool Assigned { get; set; }
    }
}
