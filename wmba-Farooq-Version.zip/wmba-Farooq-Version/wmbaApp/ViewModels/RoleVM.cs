﻿namespace wmbaApp.ViewModels
{
    public class RoleVM
    {
        public string RoleID { get; set; }

        public string RoleName { get; set; }

        public bool Assigned { get; set; }
    }
}
