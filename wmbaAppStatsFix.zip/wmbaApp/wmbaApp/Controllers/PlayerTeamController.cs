﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using wmbaApp.CustomControllers;
using wmbaApp.Data;
using wmbaApp.Models;

namespace wmbaApp.Controllers
{
    public class PlayerTeamController : ElephantController
    {
        private readonly WmbaContext _context;

        public PlayerTeamController(WmbaContext context)
        {
            _context = context;
        }

        // GET: PlayerTeam
        public async Task<IActionResult> Index(int? TeamID)
        {
            var team = await _context.Teams
            .Include(t => t.Division)
            .Include(t => t.DivisionCoaches).ThenInclude(t => t.Coach)
            .Include(t => t.Players)
            .Include(t => t.GameTeams).ThenInclude(t => t.Game)
            .Where(t => t.ID == TeamID)
            .AsNoTracking()
            .FirstOrDefaultAsync();

            ViewBag.Team = team;


            return View(await _context.Players.Where(p => p.TeamID == TeamID).ToListAsync());
        }

        // GET: PlayerTeam/Details/5
        public async Task<IActionResult> Details(int? id, int? TeamID)
        {
            if (id == null || _context.Players == null)
            {
                return NotFound();
            }

            var player = await _context.Players
                .Include(p => p.Team)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (player == null)
            {
                return NotFound();
            }

            var team = await _context.Teams
                .Include(t => t.Division)
                .Include(t => t.DivisionCoaches).ThenInclude(t => t.Coach)
                .Include(t => t.Players)
                .Include(t => t.GameTeams).ThenInclude(t => t.Game)
                .Where(t => t.ID == TeamID)
                .AsNoTracking()
                .FirstOrDefaultAsync();

            ViewBag.Team = team;

            return View(player);
        }

        // GET: PlayerTeam/Create
        public IActionResult Create()
        {
            ViewData["TeamID"] = new SelectList(_context.Teams, "ID", "TmName");
            return View();
        }

        // POST: PlayerTeam/Create
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Create([Bind("ID,PlyrFirstName,PlyrLastName,PlyrJerseyNumber,PlyrDOB,TeamID,StatsID")] Player player, int? TeamID)
        {
            if (ModelState.IsValid)
            {
                _context.Add(player);
                await _context.SaveChangesAsync();
                return RedirectToAction(nameof(Index));
            }

            var team = await _context.Teams
                .Include(t => t.Division)
                .Include(t => t.DivisionCoaches).ThenInclude(t => t.Coach)
                .Include(t => t.Players)
                .Include(t => t.GameTeams).ThenInclude(t => t.Game)
                .Where(t => t.ID == TeamID)
                .AsNoTracking()
                .FirstOrDefaultAsync();

            ViewBag.Team = team;

            return View(player);
        }

        // GET: PlayerTeam/Edit/5
        public async Task<IActionResult> Edit(int? id, int? TeamID)
        {
            if (id == null || _context.Players == null)
            {
                return NotFound();
            }

            var player = await _context.Players.FindAsync(id);
            if (player == null)
            {
                return NotFound();
            }

            var team = await _context.Teams
                .Include(t => t.Division)
                .Include(t => t.DivisionCoaches).ThenInclude(t => t.Coach)
                .Include(t => t.Players)
                .Include(t => t.GameTeams).ThenInclude(t => t.Game)
                .Where(t => t.ID == TeamID)
                .AsNoTracking()
                .FirstOrDefaultAsync();

            ViewBag.Team = team;


            return View(player);
        }

        // POST: PlayerTeam/Edit/5
        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Edit(int id, [Bind("ID,PlyrFirstName,PlyrLastName,PlyrJerseyNumber,PlyrDOB,TeamID,StatsID")] Player player, int? TeamID)
        {
            if (id != player.ID)
            {
                return NotFound();
            }

            if (ModelState.IsValid)
            {
                try
                {
                    _context.Update(player);
                    await _context.SaveChangesAsync();
                }
                catch (DbUpdateConcurrencyException)
                {
                    if (!PlayerExists(player.ID))
                    {
                        return NotFound();
                    }
                    else
                    {
                        throw;
                    }
                }
                return RedirectToAction(nameof(Index));
            }

            var team = await _context.Teams
                .Include(t => t.Division)
                .Include(t => t.DivisionCoaches).ThenInclude(t => t.Coach)
                .Include(t => t.Players)
                .Include(t => t.GameTeams).ThenInclude(t => t.Game)
                .Where(t => t.ID == TeamID)
                .AsNoTracking()
                .FirstOrDefaultAsync();

            ViewBag.Team = team;

            return View(player);
        }

        // GET: PlayerTeam/Delete/5
        public async Task<IActionResult> Delete(int? id, int? TeamID)
        {
            if (id == null || _context.Players == null)
            {
                return NotFound();
            }

            var player = await _context.Players
                .Include(p => p.Team)
                .FirstOrDefaultAsync(m => m.ID == id);
            if (player == null)
            {
                return NotFound();
            }

            var team = await _context.Teams
                .Include(t => t.Division)
                .Include(t => t.DivisionCoaches).ThenInclude(t => t.Coach)
                .Include(t => t.Players)
                .Include(t => t.GameTeams).ThenInclude(t => t.Game)
                .Where(t => t.ID == TeamID)
                .AsNoTracking()
                .FirstOrDefaultAsync();

            ViewBag.Team = team;

            return View(player);
        }

        // POST: PlayerTeam/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> DeleteConfirmed(int id, int? TeamID)
        {
            if (_context.Players == null)
            {
                return Problem("Entity set 'WmbaContext.Players'  is null.");
            }
            var player = await _context.Players.FindAsync(id);
            if (player != null)
            {
                _context.Players.Remove(player);
            }

            await _context.SaveChangesAsync();

            var team = await _context.Teams
                .Include(t => t.Division)
                .Include(t => t.DivisionCoaches).ThenInclude(t => t.Coach)
                .Include(t => t.Players)
                .Include(t => t.GameTeams).ThenInclude(t => t.Game)
                .Where(t => t.ID == TeamID)
                .AsNoTracking()
                .FirstOrDefaultAsync();

            ViewBag.Team = team;

            return RedirectToAction(nameof(Index));
        }

        private bool PlayerExists(int id)
        {
            return _context.Players.Any(e => e.ID == id);
        }
    }
}
