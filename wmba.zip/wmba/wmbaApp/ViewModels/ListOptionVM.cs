﻿namespace wmbaApp.ViewModels
{
    public class ListOptionVM
    {
        //Used for a ListBoxes
        public int ID { get; set; }
        public string DisplayText { get; set; }
    }
}
